import { Controller, Get } from '@nestjs/common';
import { HttpServiceService } from 'src/http-service/http-service.service';
import { Lead } from 'src/interfaces/lead/lead.interface';

@Controller('api/leads')
export class LeadsController {
  constructor(private readonly httpServise: HttpServiceService) {}
  @Get()
  getHello(): any {
    return this.httpServise.getUsers();
  }
}
