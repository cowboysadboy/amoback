import { Injectable } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { AmoConfigService } from 'src/amo-config/amo-config.service';
import { Lead } from 'src/interfaces/lead/lead.interface';
import { User } from 'src/interfaces/user/user.interface';

@Injectable()
export class HttpServiceService {
  access_token = '';
  refresh_token = '';
  url_amo = 'https://cowboysadboy.amocrm.ru';
  data = {
    client_id: '',
    client_secret: '',
    grant_type: 'authorization_code',
    code: '',
    redirect_uri: 'http://cowboysadboy.store/',
  };
  constructor(
    private readonly httpService: HttpService,
    private readonly AmoConfig: AmoConfigService,
  ) {
    this.access_token = this.AmoConfig.getAccessToken();
    this.refresh_token = this.AmoConfig.getRefreshToken();
    this.data.client_id = this.AmoConfig.getClientId();
    this.data.client_secret = this.AmoConfig.getClientSecret();
    this.data.code = this.AmoConfig.getCode();
    if (this.refresh_token === '') {
      this.sendPostRequest();
    }
  }
  async sendPostRequest() {
    const url = `${this.url_amo}/oauth2/access_token`;
    try {
      const response = await this.httpService.post(url, this.data).toPromise();
      this.access_token = response.data.access_token;
      this.refresh_token = response.data.refresh_token;
      console.log('Успешная авторизация');
    } catch (error) {
      if (error.response.status === 400) {
        console.log(
          'Ошибка авторизации. Попробуйте изменить настройки ключей и доступов к AMOCRM в файле env. ' +
            error.response.data.detail,
        );
      } else {
        console.log(error);
      }
    }
  }
  async getUsers(): Promise<User[]> {
    const url = `https://cowboysadboy.amocrm.ru/api/v4/users`;
    const headers = {
      Authorization: `Bearer ${this.access_token}`,
    };
    try {
      const response = await this.httpService.get(url, { headers }).toPromise();
      console.log(response.data._embedded.users);
      return response.data._embedded.users;
    } catch (error) {
      console.error(error);
    }
  }
  async getAccount(): Promise<any> {
    const url = `https://cowboysadboy.amocrm.ru/api/v4/account`;
    const headers = {
      Authorization: `Bearer ${this.access_token}`,
    };
    try {
      const response = await this.httpService.get(url, { headers }).toPromise();
      console.log(response.data);
      return response.data;
    } catch (error) {
      console.error(error);
    }
  }
  async getLeads(): Promise<Lead[]> {
    const url = `https://cowboysadboy.amocrm.ru/api/v4/leads`;
    const headers = {
      Authorization: `Bearer ${this.access_token}`,
    };
    try {
      const response = await this.httpService.get(url, { headers }).toPromise();
      return response.data._embedded.leads;
    } catch (error) {
      console.error(error);
    }
  }
  async getPipelines(): Promise<any> {
    const url = `https://cowboysadboy.amocrm.ru/api/v4/leads/pipelines`;
    const headers = {
      Authorization: `Bearer ${this.access_token}`,
    };
    try {
      const response = await this.httpService.get(url, { headers }).toPromise();
      console.log(response.data._embedded);
      return response.data;
    } catch (error) {
      console.error(error.response.data);
    }
  }
}
